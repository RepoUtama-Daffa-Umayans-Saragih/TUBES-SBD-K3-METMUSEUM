@extends('layouts.admin')

@push('styles')
@vite('resources/css/admin/dashboard/modern.css')
@endpush

@section('title', 'Admin Dashboard - MET Museum')
@section('page_title', 'Dashboard Overview')

@section('content')
<div class="museum-dashboard">
    <!-- MAIN NAVIGATION TABS -->
    <div class="dashboard-nav-tabs">
        <div class="nav-tabs-container">
            <button class="nav-tab-btn active" data-tab="overview">
                <i class="bi bi-speedometer2"></i>
                <span>Overview</span>
            </button>
            <button class="nav-tab-btn" data-tab="transactions">
                <i class="bi bi-receipt"></i>
                <span>Transactions</span>
            </button>
            <button class="nav-tab-btn" data-tab="artworks">
                <i class="bi bi-images"></i>
                <span>Artworks</span>
            </button>
        </div>
    </div>

    <!-- OVERVIEW TAB -->
    <div class="tab-content active" id="overview-tab">
        
        <!-- STATISTICS CARDS -->
        <div class="stats-grid">
            <!-- Today's Ticket Sales -->
            <div class="stat-card ticket-sales">
                <div class="stat-header">
                    <div class="stat-icon">
                        <i class="bi bi-ticket-perforated"></i>
                    </div>
                    <div class="stat-info">
                        <span class="stat-label">Today's Ticket Sales</span>
                        <h3 class="stat-value">
                            {{ 'Rp' . number_format($todayTicketSales, 0, ',', '.') }}
                        </h3>
                    </div>
                </div>
                <div class="stat-meta">
                    <span class="trend">+12% from yesterday</span>
                </div>
            </div>

            <!-- Total Tickets Sold -->
            <div class="stat-card tickets-count">
                <div class="stat-header">
                    <div class="stat-icon">
                        <i class="bi bi-bag-check"></i>
                    </div>
                    <div class="stat-info">
                        <span class="stat-label">Today's Tickets</span>
                        <h3 class="stat-value">{{ $totalTicketsSold }}</h3>
                    </div>
                </div>
                <div class="stat-meta">
                    <span class="trend">{{ $totalTicketsSold }} units</span>
                </div>
            </div>

            <!-- Monthly Revenue -->
            <div class="stat-card monthly-revenue">
                <div class="stat-header">
                    <div class="stat-icon">
                        <i class="bi bi-graph-up"></i>
                    </div>
                    <div class="stat-info">
                        <span class="stat-label">Monthly Revenue</span>
                        <h3 class="stat-value">
                            {{ 'Rp' . number_format($monthlyRevenue, 0, ',', '.') }}
                        </h3>
                    </div>
                </div>
                <div class="stat-meta">
                    <span class="trend">Current month</span>
                </div>
            </div>

            <!-- Pending Orders -->
            <div class="stat-card pending-orders">
                <div class="stat-header">
                    <div class="stat-icon">
                        <i class="bi bi-hourglass-split"></i>
                    </div>
                    <div class="stat-info">
                        <span class="stat-label">Pending Orders</span>
                        <h3 class="stat-value">{{ $pendingOrders }}</h3>
                    </div>
                </div>
                <div class="stat-meta">
                    <span class="trend" style="color: #f39c12;">Requires action</span>
                </div>
            </div>

            <!-- Total Artworks -->
            <div class="stat-card total-artworks">
                <div class="stat-header">
                    <div class="stat-icon">
                        <i class="bi bi-palette"></i>
                    </div>
                    <div class="stat-info">
                        <span class="stat-label">Total Artworks</span>
                        <h3 class="stat-value">{{ $totalArtworks }}</h3>
                    </div>
                </div>
                <div class="stat-meta">
                    <span class="trend">In collection</span>
                </div>
            </div>

            <!-- Collections -->
            <div class="stat-card collections">
                <div class="stat-header">
                    <div class="stat-icon">
                        <i class="bi bi-collection"></i>
                    </div>
                    <div class="stat-info">
                        <span class="stat-label">Collections</span>
                        <h3 class="stat-value">12</h3>
                    </div>
                </div>
                <div class="stat-meta">
                    <span class="trend">Active</span>
                </div>
            </div>
        </div>

        <!-- CHARTS SECTION -->
        <div class="charts-grid">
            <!-- Sales Chart -->
            <div class="chart-card">
                <div class="chart-header">
                    <h4>Sales Last 7 Days</h4>
                    <div class="chart-controls">
                        <button class="chart-period" data-period="daily">Daily</button>
                        <button class="chart-period" data-period="weekly">Weekly</button>
                        <button class="chart-period" data-period="monthly">Monthly</button>
                    </div>
                </div>
                <div class="chart-body">
                    <canvas id="salesChart" data-chart-type="line"></canvas>
                </div>
            </div>

            <!-- Trending Items -->
            <div class="chart-card trending-card">
                <div class="chart-header">
                    <h4>Trending Items</h4>
                </div>
                <div class="chart-body">
                    <div class="trending-list">
                        @forelse($topTicketTypes as $index => $ticket)
                            <div class="trending-item">
                                <div class="trending-rank">{{ $index + 1 }}</div>
                                <div class="trending-details">
                                    <h5>{{ $ticket->ticketType->name ?? 'Unknown' }}</h5>
                                    <p class="trending-meta">{{ $ticket->count }} sold • Rp {{ number_format($ticket->revenue, 0, ',', '.') }}</p>
                                </div>
                                <div class="trending-value">
                                    <span class="badge">{{ $ticket->count }}</span>
                                </div>
                            </div>
                        @empty
                            <p class="empty-state">No trending items yet</p>
                        @endforelse
                    </div>
                </div>
            </div>
        </div>

        <!-- RECENT TRANSACTIONS -->
        <div class="recent-section">
            <div class="section-header">
                <h4>Recent Transactions</h4>
                <a href="#" class="view-all" onclick="switchTab('transactions'); return false;">View All →</a>
            </div>
            
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Date</th>
                            <th>Customer</th>
                            <th>Items</th>
                            <th>Amount</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($recentTransactions as $trans)
                            <tr>
                                <td class="cell-id">{{ $trans->order_code }}</td>
                                <td>{{ $trans->order_date->format('M d, Y H:i') }}</td>
                                <td>{{ $trans->user->name ?? 'Guest' }}</td>
                                <td>{{ $trans->orderDetails->sum('quantity') }}</td>
                                <td class="cell-amount">Rp {{ number_format($trans->total_amount, 0, ',', '.') }}</td>
                                <td>
                                    <span class="status-badge status-{{ strtolower($trans->status) }}">
                                        {{ ucfirst($trans->status) }}
                                    </span>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="empty-cell">No transactions yet</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- TRANSACTIONS TAB (Placeholder - will be loaded dynamically) -->
    <div class="tab-content" id="transactions-tab"></div>

    <!-- ARTWORKS TAB (Placeholder - will be loaded dynamically) -->
    <div class="tab-content" id="artworks-tab"></div>
</div>

@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize charts
    initializeSalesChart();
    
    // Tab switching
    document.querySelectorAll('.nav-tab-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            switchTab(this.dataset.tab);
        });
    });
});

function switchTab(tabName) {
    // Remove active from all tabs and contents
    document.querySelectorAll('.nav-tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    
    // Add active to clicked tab
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    document.getElementById(`${tabName}-tab`).classList.add('active');
    
    // Load content if needed
    if (tabName === 'transactions' && !document.querySelector('#transactions-tab').dataset.loaded) {
        loadTransactionsTab();
    } else if (tabName === 'artworks' && !document.querySelector('#artworks-tab').dataset.loaded) {
        loadArtworksTab();
    }
}

function loadTransactionsTab() {
    const container = document.getElementById('transactions-tab');
    container.innerHTML = '<div class="loading">Loading...</div>';
    container.setAttribute('data-loaded', 'true');
    // Content will be loaded via AJAX or Livewire
}

function loadArtworksTab() {
    const container = document.getElementById('artworks-tab');
    container.innerHTML = '<div class="loading">Loading...</div>';
    container.setAttribute('data-loaded', 'true');
    // Content will be loaded via AJAX or Livewire
}

function initializeSalesChart() {
    const ctx = document.getElementById('salesChart');
    if (!ctx) return;

    const data = @json($last7Days);
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.map(d => d.label),
            datasets: [{
                label: 'Sales Revenue',
                data: data.map(d => d.sales),
                borderColor: '#2c3e50',
                backgroundColor: 'rgba(44, 62, 80, 0.1)',
                tension: 0.4,
                fill: true,
                borderWidth: 2,
                pointBackgroundColor: '#3498db',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 7
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        color: '#666',
                        font: { size: 12 }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#666',
                        callback: function(value) {
                            return 'Rp ' + value.toLocaleString('id-ID');
                        }
                    },
                    grid: {
                        color: 'rgba(0,0,0,0.05)'
                    }
                },
                x: {
                    ticks: { color: '#666' },
                    grid: { display: false }
                }
            }
        }
    });
}
</script>
@endpush
